import java.util.Scanner;

public class DiceRoller {
    private int dieType;
    private int numDice;
    private int targetNumber;
    private Die die;
    
    public DiceRoller() {
        Scanner scanner = new Scanner(System.in);
        
        // Define valid die types and ask user for input
        int[] validDieTypes = {4, 6, 8, 10, 12, 20, 100};
        System.out.println("Enter a valid die type (4, 6, 8, 10, 12, 20, 100): ");
        dieType = scanner.nextInt();
        while (!isValidDieType(validDieTypes, dieType)) {
            System.out.println("Invalid die type. Enter a valid die type: ");
            dieType = scanner.nextInt();
        }
        
        // Ask user for number of dice
        System.out.println("Enter the number of dice (max 10): ");
        numDice = scanner.nextInt();
        while (numDice < 1 || numDice > 10) {
            System.out.println("Invalid number of dice. Enter the number of dice (max 10): ");
            numDice = scanner.nextInt();
        }
        
        // Ask user for target number
        System.out.println("Enter the target number (min 5, max 30): ");
        targetNumber = scanner.nextInt();
        while (targetNumber < 5 || targetNumber > 30) {
            System.out.println("Invalid target number. Enter the target number (min 5, max 30): ");
            targetNumber = scanner.nextInt();
        }
        
    
    }
    
    // Helper method to check if a die type is valid
    private boolean isValidDieType(int[] validDieTypes, int dieType) {
        for (int i = 0; i < validDieTypes.length; i++) {
            if (dieType == validDieTypes[i]) {
                return true;
            }
        }
        return false;
    }
    
    // Roll the dice and check for busts or open-ended rolls
    public int rollDice() {
        int numOnes = 0;
        int total = 0;
        boolean openEnded = false;
        
        for (int i = 0; i < numDice; i++) {
            int result = die.roll();
            total += result;
            
            // Check for bust
            if (result == 1) {
                numOnes++;
            }
            if (numOnes > numDice / 2) {
                System.out.println("Bust! More than 50% of the dice were ones.");
                return -1;
            }
            
            // Check for open-ended roll
            if (result == dieType) {
                System.out.println("Open-ended roll! Rolling another die.");
                openEnded = true;
            }
            
            // Roll another die if open-ended roll
            while (openEnded) {
                int newRoll = die.roll();
                total += newRoll;
                
                if (newRoll == dieType) {
                    System.out.println("Open-ended roll! Rolling another die.");
                } else {
                    openEnded = false;
                }
            }
        }
        
        // Print the result
        System.out.println("Total: " + total);
        
        // Return 1 for success, 0 for failure
        return (total >= targetNumber) ? 1 : 0;
    }
}

